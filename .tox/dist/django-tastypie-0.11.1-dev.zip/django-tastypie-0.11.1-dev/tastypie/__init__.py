from __future__ import unicode_literals


__author__ = 'Daniel Lindsley & the Tastypie core team'
__version__ = (0, 11, 1, 'dev')
